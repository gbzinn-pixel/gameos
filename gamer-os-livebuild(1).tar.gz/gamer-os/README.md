# GamerOS (Debian 13 trixie + XFCE + Pegasus)

## Build (em Debian/Ubuntu, com internet, ~25 GB livres)
    sudo apt install live-build
    chmod +x auto/* config/hooks/live/*
    sudo lb config
    sudo lb build        # log em build.log
    sudo lb clean        # limpar (--purge para limpar tudo)

Teste na VM:
    qemu-system-x86_64 -enable-kvm -m 4G -cdrom live-image-amd64.hybrid.iso

## Como funciona
- Boot: LightDM autologin -> XFCE -> Pegasus abre em tela cheia (Modo Console).
- Item "Area de trabalho" fecha o Pegasus; "Modo Console" no menu reabre.
- Apps abertos via gamemoderun ativam o Modo Gamer (gamemode.ini chama gamer-mode on/off).
- Jogos da Steam: opcoes de inicializacao -> gamemoderun %command%

## Ajustes provaveis
- Pacote nao encontrado (ex.: ppsspp): comente a linha em config/package-lists.
- Hooks 0200-0400 baixam do GitHub; se mudarem o nome dos arquivos, ajuste o jq.
- Capas/icones: adicione assets.logo em metafile.pegasus.txt.
