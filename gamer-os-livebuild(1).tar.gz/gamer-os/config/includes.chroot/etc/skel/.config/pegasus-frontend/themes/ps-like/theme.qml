import QtQuick 2.12

FocusScope {
    id: root
    property var apps: api.collections.get(0).games

    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#101a45" }
            GradientStop { position: 1.0; color: "#03050f" }
        }
    }

    Text {
        x: 80; y: 48
        text: "Jogos"
        color: "white"; font.pixelSize: 40; font.bold: true
    }

    Text {
        id: clock
        anchors { top: parent.top; right: parent.right; topMargin: 48; rightMargin: 80 }
        color: "white"; font.pixelSize: 34
        Timer {
            interval: 1000; running: true; repeat: true; triggeredOnStart: true
            onTriggered: clock.text = Qt.formatTime(new Date(), "hh:mm")
        }
    }

    ListView {
        id: tiles
        focus: true
        x: 80; y: 150
        width: parent.width - 160; height: 320
        orientation: ListView.Horizontal
        spacing: 24
        model: root.apps
        highlightMoveDuration: 120

        Keys.onLeftPressed: decrementCurrentIndex()
        Keys.onRightPressed: incrementCurrentIndex()
        Keys.onPressed: {
            if (api.keys.isAccept(event) && !event.isAutoRepeat) {
                event.accepted = true;
                root.apps.get(currentIndex).launch();
            }
        }

        delegate: Item {
            property bool selected: ListView.isCurrentItem
            width: selected ? 240 : 170
            height: tiles.height
            Behavior on width { NumberAnimation { duration: 120 } }

            Rectangle {
                id: card
                width: parent.width
                height: parent.width
                radius: 16
                color: selected ? "#2a3566" : "#1a2040"
                border.width: selected ? 3 : 0
                border.color: "white"
                Text {
                    anchors.centerIn: parent
                    text: modelData.title.charAt(0)
                    color: "white"; font.pixelSize: parent.width / 2; font.bold: true
                }
            }
            Text {
                anchors { top: card.bottom; topMargin: 12; horizontalCenter: card.horizontalCenter }
                text: modelData.title
                color: "white"; font.pixelSize: 22
                visible: selected
            }
            MouseArea {
                anchors.fill: parent
                onClicked: { tiles.currentIndex = index; modelData.launch(); }
            }
        }
    }

    Row {
        x: 80; y: parent.height - 220
        spacing: 24
        Repeater {
            model: [
                { t: "Modo Gamer", d: "Ativa sozinho ao abrir um jogo" },
                { t: "Area de trabalho", d: "Escolha 'Area de trabalho' na lista" },
                { t: "Dica", d: "Use gamemoderun nos jogos da Steam" }
            ]
            Rectangle {
                width: 380; height: 140; radius: 14; color: "#14193a"
                Column {
                    anchors { left: parent.left; top: parent.top; margins: 20 }
                    spacing: 10
                    Text { text: modelData.t; color: "white"; font.pixelSize: 24; font.bold: true }
                    Text { text: modelData.d; color: "#b8c0e0"; font.pixelSize: 18 }
                }
            }
        }
    }
}
