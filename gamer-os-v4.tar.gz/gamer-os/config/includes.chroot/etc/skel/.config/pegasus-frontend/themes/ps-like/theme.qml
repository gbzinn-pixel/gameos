import QtQuick 2.12

FocusScope {
    id: root
    property var apps: api.collections.get(0).games
    property bool launching: false
    property var colors: ({
        "steam": "#2a8be0", "lutris": "#ff9a3c", "heroic": "#8b6cff",
        "ppsspp": "#2fd1b0", "firefox": "#ff6b4c", "arquivos": "#55b3ff",
        "terminal": "#69db7c", "areadetrabalho": "#3fe0b5"
    })
    function keyOf(title) { return title.toLowerCase().replace(/[^a-z]/g, "") }

    opacity: 0
    Component.onCompleted: { fadeIn.start(); tiles.forceActiveFocus() }
    NumberAnimation { id: fadeIn; target: root; property: "opacity"; from: 0; to: 1; duration: 450 }

    Rectangle { anchors.fill: parent; color: "#050a24" }
    Image {
        anchors.fill: parent
        source: "file:///usr/share/backgrounds/gamer-os/wallpaper.png"
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }
    Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.30 }

    // Cabecalho
    Text {
        x: 90; y: 54
        text: "Jogos"
        color: "white"; font.pixelSize: 42; font.bold: true
    }
    Text {
        x: 210; y: 66
        text: "Apps"
        color: "#9aa5d6"; font.pixelSize: 28
    }
    Column {
        anchors { top: parent.top; right: parent.right; topMargin: 48; rightMargin: 90 }
        spacing: 2
        Text { id: clock; anchors.right: parent.right; color: "white"; font.pixelSize: 36 }
        Text { id: dateText; anchors.right: parent.right; color: "#9aa5d6"; font.pixelSize: 18 }
        Timer {
            interval: 1000; running: true; repeat: true; triggeredOnStart: true
            onTriggered: {
                var d = new Date()
                clock.text = Qt.formatTime(d, "hh:mm")
                dateText.text = Qt.formatDate(d, "dddd, d MMMM")
            }
        }
    }

    // Faixa de apps
    ListView {
        id: tiles
        x: 90
        y: parent.height * 0.26
        width: parent.width - 180
        height: 340
        orientation: ListView.Horizontal
        spacing: 30
        model: root.apps
        currentIndex: 0
        highlightMoveDuration: 220
        highlightRangeMode: ListView.ApplyRange
        preferredHighlightBegin: 0
        preferredHighlightEnd: width * 0.6
        clip: false

        Keys.onLeftPressed: if (!root.launching) decrementCurrentIndex()
        Keys.onRightPressed: if (!root.launching) incrementCurrentIndex()
        Keys.onPressed: {
            if (api.keys.isAccept(event) && !event.isAutoRepeat && !root.launching) {
                event.accepted = true
                root.launching = true
                launchAnim.start()
            }
        }

        delegate: Item {
            id: cell
            property bool sel: ListView.isCurrentItem
            property string key: root.keyOf(modelData.title)
            width: sel ? 250 : 168
            height: tiles.height
            Behavior on width { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

            Rectangle {
                id: glow
                anchors.centerIn: card
                width: card.width + 30; height: card.height + 30
                radius: 44
                color: root.colors[cell.key] ? root.colors[cell.key] : "#6677ff"
                opacity: cell.sel ? 0.35 : 0
                Behavior on opacity { NumberAnimation { duration: 200 } }
            }
            Rectangle {
                id: card
                width: parent.width; height: parent.width
                radius: 36
                color: "#141a3a"
                border.width: cell.sel ? 3 : 0
                border.color: "white"
                Image {
                    anchors.centerIn: parent
                    width: parent.width * 0.82; height: width
                    source: "file:///usr/share/gamer-os/icons/" + cell.key + ".png"
                    smooth: true; asynchronous: true
                }
            }
            Text {
                anchors { top: card.bottom; topMargin: 16; horizontalCenter: card.horizontalCenter }
                text: modelData.title
                color: "white"; font.pixelSize: 26; font.bold: true
                opacity: cell.sel ? 1 : 0
                Behavior on opacity { NumberAnimation { duration: 180 } }
            }
            MouseArea {
                anchors.fill: parent
                onClicked: {
                    if (root.launching) return
                    tiles.currentIndex = index
                    root.launching = true
                    launchAnim.start()
                }
            }
        }
    }

    // animacao ao abrir um app
    SequentialAnimation {
        id: launchAnim
        ParallelAnimation {
            NumberAnimation { target: tiles; property: "scale"; to: 1.12; duration: 180; easing.type: Easing.OutCubic }
            NumberAnimation { target: tiles; property: "opacity"; to: 0.0; duration: 200 }
        }
        ScriptAction { script: root.apps.get(tiles.currentIndex).launch() }
        PauseAnimation { duration: 700 }
        ScriptAction { script: { tiles.scale = 1; tiles.opacity = 1; root.launching = false } }
    }

    // Rodape com atalhos
    Rectangle {
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 50 }
        width: hints.width + 70; height: 54; radius: 27
        color: "#141a3a"; opacity: 0.9
        Text {
            id: hints
            anchors.centerIn: parent
            text: "Enter  Abrir      Super+G  Modo Gamer      Super+C  Console / Área de trabalho"
            color: "#c9d1ff"; font.pixelSize: 20
        }
    }
}
